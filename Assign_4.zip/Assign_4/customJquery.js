
$(document).ready(function () {
$("#home").show(); //by deafault , show home page and hide all others
$("#aboutMe").hide();
   $("#work").hide();
    $("#myThought").hide();
$("li.active").click(function () { //on click of Home menu
    // Rmove and add class "active"
	$(".home").removeClass("active");
	$(".home").addClass("active");
	$(".aboutMe").removeClass("active");
	$(".work").removeClass("active");
	$(".myThought").removeClass("active");
    $("#home").show();
    $("#aboutMe").hide();
    $("#work").hide();
    $("#myThought").hide();
});
$("li.aboutMe").click(function () { //on click of aboutMe menu
$("li.active").removeClass("active");
    // Rmove and add class "active"
	$(".aboutMe").removeClass("active");
	$(".aboutMe").addClass("active");
    $("#aboutMe").show();
    $("#home").hide();
    $("#home").hide();
    $("#work").hide();
    $("#myThought").hide();
});
$("li.work").click(function () { ////on click of Work menu
    $("#aboutMe").hide();
    $("#home").hide();
	// Rmove and add class "active"
	$(".work").addClass("active");
	$(".home").removeClass("active");
	$(".aboutMe").removeClass("active");
	$(".myThought").removeClass("active");
    $("#work").show();
    $("#myThought").hide();
});
$("li.myThought").click(function () { //on click of myThought menu
    $("#aboutMe").hide();
    $("#home").hide();
    $("#work").hide();
    $("#myThought").show();
	// Rmove and add class "active"
	$(".myThought").addClass("active");
	$(".work").removeClass("active");
	$(".home").removeClass("active");
	$(".aboutMe").removeClass("active");	
});
});